package com.checongbinh.daoimp;

import java.util.List;

import com.checongbinh.entity.MauSanPham;

public interface MauSanPhamImp {
	List<MauSanPham> LayDanhSachMau();
}
