package com.checongbinh.daoimp;

import java.util.List;

import com.checongbinh.entity.SizeSanPham;

public interface SizeSanPhamImp {
	List<SizeSanPham> LayDanhSachSize();
}
