package com.checongbinh.daoimp;

import com.checongbinh.entity.ChiTietHoaDon;

public interface ChiTietHoaDonImp {
	boolean ThemChiTietHoaDon(ChiTietHoaDon chiTietHoaDon);
}
