package com.checongbinh.daoimp;

import com.checongbinh.entity.HoaDon;

public interface HoaDonImp {
	int ThemHoaDon(HoaDon hoaDon);
}
