package com.checongbinh.daoimp;

import java.util.List;

import com.checongbinh.entity.DanhMucSanPham;

public interface DanhMucImp {	
	List<DanhMucSanPham> LayDanhMuc();
}
